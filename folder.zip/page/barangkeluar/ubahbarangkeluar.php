<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/css/bootstrap-select.min.css" rel="stylesheet">






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script>  




   <script>
 function sum() {
	 var stok = document.getElementById('stok').value;
	 var jumlahkeluar = document.getElementById('jumlahkeluar').value;
	 var result = parseInt(stok) - parseInt(jumlahkeluar);
	 if (!isNaN(result)) {
		 document.getElementById('total').value = result;
	 }
 }
 </script>
  
<?php
 $id = $_GET['id'];
 $sql2 = $koneksi->query("select * from barang_keluar where id = '$id'");
 $tampil = $sql2->fetch_assoc();
 
 $level = $tampil['level'];

 
 
 
 ?>



  
  <div class="container-fluid">

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Ubah Asset Keluar</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
							
							
							<div class="body">
							
							<form method="POST" enctype="multipart/form-data">
							
							<label for="">Id Transaksi</label>
                            <div class="form-group">
                               <div class="form-line">
                                <input type="text" name="id_transaksi" class="form-control" id="id_transaksi"  value="<?php echo $tampil['id_transaksi']; ?>" required autofocus />  
							</div>
                            </div>
							
						
							
							<label for="">Tanggal Keluar</label>
                            <div class="form-group">
                               <div class="form-line">
                                 <input type="date" name="tanggal_keluar" class="form-control" id="tanggal_kelauar" value="<?php echo $tampil['tanggal_keluar']; ?>" required autofocus />
							</div>
                            </div>
							
					
							<label for="">Asset</label>
                            <div class="form-group">
                               <div class="form-line">
                                <select name="barang" id="cmb_barang" class="selectpicker form-control" data-live-search="true" required autofocus />
								<option value="">-- Pilih Asset  --</option>
								<?php
								
								$sql = $koneksi -> query("select * from gudang1 order by kode_barang");
								while ($data=$sql->fetch_assoc()) {
									echo "<option value='$data[kode_barang].$data[nama_barang]'>$data[kode_barang] | $data[nama_barang]</option>";
								}
								?>
								
								</select>
                                     
									 
							</div>
                            </div>
							<div class="tampung"></div>
					
							<label for="">Jumlah</label>
                            <div class="form-group">
                               <div class="form-line">
                                <input type="text" name="jumlahkeluar" id="jumlahkeluar" onkeyup="sum()" class="form-control" value="<?php echo $tampil['jumlahkeluar']; ?>" required autofocus />
							
                                     
									 
							</div>
                            </div>
							
							<label for="total">Total Stok</label>
                            <div class="form-group">
                               <div class="form-line">
                               <input readonly="readonly" name="total" id="total"  type="number" class="form-control">
                            

							</div>
                            </div>
							<div class="tampung1"></div>
							
							<label for="">Relasi</label>
                            <div class="form-group">
                               <div class="form-line">
							   <select name="tujuan"  class="selectpicker form-control" data-live-search="true" required autofocus />
							<option value="">-- Pilih Relasi  --</option>
							<?php
							
							$sql = $koneksi -> query("select * from tb_relasi order by nama_supplier");
							while ($data=$sql->fetch_assoc()) {
							echo "<option value='$data[nama_supplier]'>$data[nama_supplier]</option>";
							}
							?>
							
							</select> 
							</div>
                            </div>
						
						
							
							<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
							
							</form>
							
							
							
							<?php
							
								if (isset($_POST['simpan'])) {
								$id_transaksi= $_POST['id_transaksi'];
								$tanggal= $_POST['tanggal_keluar'];

								$barang= $_POST['barang'];
								$pecah_barang = explode(".", $barang);
								$kode_barang = $pecah_barang[0];
								$nama_barang = $pecah_barang[1];
								$jumlah= $_POST['jumlahkeluar'];
								
								$satuan= $_POST['satuan'];

								$tujuan= $_POST['tujuan'];
							
								
								$total= $_POST['total'];
								$sisa2 = $total;
								if ($sisa2 < 0) {
									?>
									
										<script type="text/javascript">
										alert("Stok Barang Habis, Transaksi Tidak Dapat Dilakukan");
										window.location.href="?page=barangkeluar&aksi=ubahbarangkeluar";
										</script>
										<?php
											
								}else {
								
								$sql=$koneksi->query("update barang_keluar set id_transaksi='$id_transaksi' , tanggal='$tanggal_keluar',kode_barang='$kode_barang',nama_barang='$nama_barang',jumlah='$jumlahkeluar', tujuan='$tujuan', satuan='$satuan' where id_transaksi='$id_transaksi'");
								$query1="update gudang1 set jumlah=(jumlah) where kode_barang='$kode_barang'";
								$sql2=$koneksi->query($query1);
								
								if ($sql) {
									?>


									
									
									<script type="text/javascript">
										alert("Data Berhasil di Update");
										window.location.href="?page=barangkeluar";
										
										</script>
										<?php
								}

								}
							}
							
							
							?>
								
								
								
								
								
