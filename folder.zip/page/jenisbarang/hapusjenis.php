<?php
 $jenis_barang = $_GET['jenis_barang'];
 $sql = $koneksi->query("delete from jenis where jenis_barang = '$jenis_barang'");
 if ($sql) {
  ?>
  	<script type="text/javascript">
	alert("Data Berhasil Dihapus");
	window.location.href="?page=jenisbarang";
	</script>
	
 <?php
 
 }
 
 ?>