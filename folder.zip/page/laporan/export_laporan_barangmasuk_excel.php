
<?php
if (isset($_POST['submit']))
{?>

 <?php



	$koneksi = new mysqli("localhost","root","","barang");

	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Laporan_Asset_Masuk (".date('d-m-Y').").xls");
	
	$bln = $_POST['bln'] ;
	$thn = $_POST['thn'] ;

?>	

<body>
<center>
<h2>PT SENTOSA ULTRA GASINDO <br>Laporan Barang Masuk Bulan <?php echo $bln;?> Tahun <?php echo $thn;?></h2>
</center>
<table border="1">
  <tr>
											<th>No</th>
											<th>Id Transaksi</th>
											<th>Tanggal Masuk</th>
											<th>Kode Asset</th>
											<th>Nama Asset</th>
										
											<th>Relasi</th>
											

											<th>Jumlah </th>
											<th>Satuan </th>
										
                                         
                                        </tr>
	

                    <?php 
									
									$no = 1;
									$sql = $koneksi->query("select * from barang_masuk where MONTH(tanggal) = '$bln' and YEAR(tanggal) = '$thn'");
									while ($data = $sql->fetch_assoc()) {
										
									?>
									
                                        <tr>
                                            <td><?php echo $no++; ?></td>
											<td><?php echo $data['id_transaksi'] ?></td>
											<td><?php echo $data['tanggal'] ?></td>
											<td><?php echo $data['kode_barang'] ?></td>
											<td><?php echo $data['nama_barang'] ?></td>
											
											<td><?php echo $data['pengirim'] ?></td>

											<td><?php echo $data['jumlah'] ?></td>
										<td><?php echo $data['satuan'] ?></td>
								

                                        </tr>
									<?php }?>
<?php 
									
									$no = 1;
									$sql = $koneksi->query("select sum(jumlah) as total from barang_masuk where MONTH(tanggal) = '$bln' and YEAR(tanggal) = '$thn'");
									while ($data = $sql->fetch_assoc()) {
										
									?>
					<tr>
						
						<th colspan="6" style="text-align:center;" style="font-style:bold; ">Total Asset Masuk</th>
						<th colspan="2" style="text-align:center;" style="font-style:bold;"><?php echo $data['total'] ?></th>
			      			
					</tr>
<?php }?>					

</table>	
					</body>
                                
	<?php 
	}
	?>
	
	<?php

	$koneksi = new mysqli("localhost","root","","barang");
	

	$bln = $_POST['bln'] ;
	$thn = $_POST['thn'] ;
	?>
	
	<?php
	if ($bln == 'all') {
		?>
	<div class="table-responsive">
							
                                <table  class="display table table-bordered" id="transaksi">
								
                                    <thead>
                                      <tr>
											<th>No</th>
											<th>Id Transaksi</th>
											<th>Tanggal Masuk</th>
											<th>Kode Asset</th>
											<th>Nama Asset</th>
											<th>Relasi</th>
											<th>Jumlah</th>
											<th>Satuan</th>
										
                                         
                                        </tr>
                                    </thead>
		<tbody>
									
		
		<?php
		$no = 1;
		$sql = $koneksi->query("select * from barang_masuk where YEAR(tanggal) = '$thn'");
		while ($data = $sql->fetch_assoc()) {
									
		?>
	
						
				 <tr>
                                            <td><?php echo $no++; ?></td>
											<td><?php echo $data['id_transaksi'] ?></td>
											<td><?php echo $data['tanggal'] ?></td>
											<td><?php echo $data['kode_barang'] ?></td>
											<td><?php echo $data['nama_barang'] ?></td>
											
											<td><?php echo $data['pengirim'] ?></td>
									
                                         
											<td><?php echo $data['jumlah'] ?></td>
											<td><?php echo $data['satuan'] ?></td>
								

                                        </tr>
						<?php 
						}
						?>

					</tbody>
                   
<?php 
									
									$no = 1;
									$sql = $koneksi->query("select sum(jumlah) as total from barang_masuk where YEAR(tanggal) = '$thn'");
									while ($data = $sql->fetch_assoc()) {
										
									?>
					<tr>
						
						<th colspan="6" style="text-align:center;" style="font-style:bold; ">Total Asset Masuk</th>
						<th colspan="2" style="text-align:center;" style="font-style:bold;"><?php echo $data['total'] ?></th>
			      			
					</tr>
<?php }?>	


 </table>
					</div>
					
					
					<?php
					}
					else{ ?>
						<div class="table-responsive">
							
                                <table  class="display table table-bordered" id="transaksi">
								
                                     <thead>
                                      <tr>
											<th>No</th>
											<th>Id Transaksi</th>
											<th>Tanggal Masuk</th>
											<th>Kode Asset</th>
											<th>Nama Asset</th>
											<th>Relasi</th>
											<th>Jumlah</th>
											<th>Satuan</th>
						
                                        </tr>
                                    </thead>
		<tbody>
									
		
		<?php
		$no = 1;
		$sql = $koneksi->query("select * from barang_masuk where MONTH(tanggal) = '$bln' and YEAR(tanggal) = '$thn'");
			while ($data = $sql->fetch_assoc()) {
									
		?>
	
						 <tr>
                                            <td><?php echo $no++; ?></td>
											<td><?php echo $data['id_transaksi'] ?></td>
											<td><?php echo $data['tanggal'] ?></td>
											<td><?php echo $data['kode_barang'] ?></td>
											<td><?php echo $data['nama_barang'] ?></td>
											
											<td><?php echo $data['pengirim'] ?></td>
									
                                         
											<td><?php echo $data['jumlah'] ?></td>
											<td><?php echo $data['satuan'] ?></td>
								
								

                                        </tr>
						<?php 
		}
		?>
    </tbody>
<?php 
									
									$no = 1;
									$sql = $koneksi->query("select sum(jumlah) as total from barang_masuk where MONTH(tanggal) = '$bln' and YEAR(tanggal) = '$thn'");
									while ($data = $sql->fetch_assoc()) {
										
									?>
					<tr>
						
						<th colspan="6" style="text-align:center;" style="font-style:bold; ">Total Asset Masuk</th>
						<th colspan="2" style="text-align:center;" style="font-style:bold;"><?php echo $data['total'] ?></th>
			      			
					</tr>
<?php }?>				


</table>
</div>
	
	<?php

}

?>