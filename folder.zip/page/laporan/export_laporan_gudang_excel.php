 <?php
	
	$koneksi = new mysqli("localhost","root","","barang");

	
	
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Laporan_Stok_Gudang(".date('d-m-Y').").xls");

?>

<center>	
<h2>PT SENTOSA ULTRA GASINDO <br> Laporan Data Asset Gudang</h2>
</center>
<table border="1">
	  <tr>
											<th>No</th>
											<th>Kode Asset</th>
											<th>Nama Asset</th>											
											<th>Jenis </th>
											<th>Jumlah </th>
											<th>Satuan</th>
											<th>Catatan</th>
										
                                         
                                        </tr>
	
 <?php 
									
									$no = 1;
									$sql = $koneksi->query("select * from gudang1");
									while ($data = $sql->fetch_assoc()) {
										
									?>
									
                                        <tr>
                                            						<td><?php echo $no++; ?></td>
											<td><?php echo $data['kode_barang'] ?></td>
											<td><?php echo $data['nama_barang'] ?></td>
											<td><?php echo $data['jenis_barang'] ?></td>
											<td><?php echo $data['jumlah'] ?></td>
											<td><?php echo $data['satuan'] ?></td>
											<td><?php echo $data['catatan'] ?></td>
								

								

										
                                        </tr>

									<?php }?>
<?php 
									
									$no = 1;
									$sql = $koneksi->query("select sum(jumlah) as total from gudang1");
									while ($data = $sql->fetch_assoc()) {
										
									?>
					<tr>
						
						<th colspan="4" style="text-align:center;" style="font-style:bold; ">Total Asset Storage</th>
						<th colspan="3" style="text-align:center;" style="font-style:bold;"><?php echo $data['total'] ?></th>
			      			
					</tr>
<?php }?>
                                </table>