 <?php

	$koneksi = new mysqli("localhost","root","","barang");

	
	
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Laporan_Relasi(".date('d-m-Y').").xls");

?>

	



<center>
<h2>PT SENTOSA ULTRA GASINDO <br>Laporan Data Relasi</h2>
</center>
<table border="1">
	 <tr>
			<th>No</th>
											<th>Tanggal Keluar</th>
											<th>Tanggal Masuk</th>
											<th>Nama Relasi</th>
											<th>Nama Asset</th>
											<th>Kode Asset</th>
											<th>Jumlah</th>
											
	</tr>
	
	<?php
		$no = 1;
		$sql = $koneksi->query("select * from tb_relasi1");
		while ($data = $sql->fetch_assoc()) {	
	
		
	
	
	
	?>
	
	<tr>
		   <td><?php echo $no++; ?></td>
											<td><?php echo $data['tanggal_keluar'] ?></td>
											<td><?php echo $data['tanggal_masuk'] ?></td>
											<td><?php echo $data['nama_supplier'] ?></td>
											<td><?php echo $data['nama_barang'] ?></td>
											<td><?php echo $data['kode_barang'] ?></td>
											<td><?php echo $data['jumlah'] ?></td>
					
	</tr>
	
	
	
	
	<?php
	
	}
	
	?>
	

<?php 
									
									$no = 1;
									$sql = $koneksi->query("select sum(jumlah) as total from tb_relasi1 ");
									while ($data = $sql->fetch_assoc()) {
										
									?>
					<tr>
						
						<th colspan="6" style="text-align:center;" style="font-style:bold; ">Total Asset Relasi</th>
						<th colspan="0" style="text-align:center;" style="font-style:bold;"><?php echo $data['total'] ?></th>
			      			
					</tr>
<?php }?>
	</table>