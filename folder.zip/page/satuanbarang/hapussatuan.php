 <?php
 
 $kode_satuan = $_GET['kode_satuan'];
 $sql = $koneksi->query("delete from tb_satuan where kode_satuan = '$kode_satuan'");
 if ($sql) {
 
 ?>
 
 
	<script type="text/javascript">
	alert("Data Berhasil Dihapus");
	window.location.href="?page=satuanbarang";
	</script>
	
 <?php
 
 }
 
 ?>




