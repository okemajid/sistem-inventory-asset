 <?php
 
 $kode_supplier= $_GET['kode_supplier'];
 $sql = $koneksi->query("delete from tb_relasi1 where kode_supplier = '$kode_supplier'");

 if ($sql) {
 
 ?>
 
 
	<script type="text/javascript">
	alert("Data Berhasil Dihapus");
	window.location.href="?page=supplier";
	</script>
	
 <?php
 
 }
 
 ?>