




 <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Asset Relasi</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                                        <tr>
											<th>No</th>
											<th>Tanggal Keluar</th>
											<th>Tanggal Masuk</th>
											<th>Nama Relasi</th>
		    	 								<th>Nama Asset</th>
                     									<th>Kode Asset</th>
											<th>Jumlah</th>
                    	  								<th>Pengaturan</th>
                                         
                                        </tr>
										</thead>
										
               
                  <tbody>
                    <?php 
									
									$no = 1;
									$sql = $koneksi->query("select * from tb_relasi1");
									while ($data = $sql->fetch_assoc()) {
										
									?>
									
                                        <tr>
                                            <td><?php echo $no++; ?></td>
											
											
											<td><?php echo $data['tanggal_keluar']?></td>
											<td><?php echo $data['tanggal_masuk']?></td>
											<td><?php echo $data['nama_supplier'] ?></td>
                    									<td><?php echo $data['nama_barang'] ?></td>
                     									<td><?php echo $data['kode_barang'] ?> </td>
                                                               				<td><?php echo $data['jumlah'] ?> </td>

											<td>
											<a href="?page=supplier&aksi=ubahsupplier&kode_supplier=<?php echo $data['kode_supplier'] ?>" class="btn btn-success" >Ubah</a>
											<a onclick="return confirm('Apakah anda yakin akan menghapus data ini?')" href="?page=supplier&aksi=hapussupplier&nama_supplier=<?php echo $data['nama_supplier'] ?>" class="btn btn-danger" >Hapus</a>
											</td>
                                        </tr>
									<?php }?>

										   </tbody>
                                </table>
								<a href="?page=supplier&aksi=tambahsupplier" class="btn btn-primary" >Tambah Asset Relasi</a>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>












