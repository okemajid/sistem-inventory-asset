<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/css/bootstrap-select.min.css" rel="stylesheet">






<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script>  





<?php
 $kode_supplier = $_GET['kode_supplier'];
 $sql2 = $koneksi->query("select * from tb_relasi1 where nama_supplier = '$nama_supplier'");
 $tampil = $sql2->fetch_assoc();
 

 
 
 
 ?>
 
  <div class="container-fluid">

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Ubah Data Asset Relasi</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
							
							
							<div class="body">

							<form method="POST" enctype="multipart/form-data">
				<label for="">Tanggal Keluar</label>
                            <div class="form-group">
                               <div class="form-line">
                                 <input type="date" name="tanggal_keluar" class="form-control" id="tanggal_kelauar" value="<?php echo $tanggal_keluar; ?>"  />
							</div>
                            </div>
							
							<label for="">Tanggal Masuk</label>
                            <div class="form-group">
                               <div class="form-line">
                                 <input type="date" name="tanggal_masuk" class="form-control" id="tanggal_masuk" value="<?php echo $tanggal_masuk; ?>" />
							</div>
                            </div>
							
							<label for="">Nama Relasi</label>
                            <div class="form-group">
                               <div class="form-line">
                                <select name="relasi" id="cmb_relasi" class="selectpicker form-control" data-live-search="true" required autofocus />
								<option value="">-- Pilih Relasi --</option>
								<?php
								
								$sql = $koneksi -> query("select * from tb_supplier order by kode_supplier");
								while ($data=$sql->fetch_assoc()) {
									echo "<option value='$data[kode_supplier].$data[nama_supplier]'>$data[kode_supplier] | $data[nama_supplier]</option>";
								}
								?>
								
								</select>
                                     
									 
							</div>
                            </div>

							
					
							
							<label for="">Asset</label>
                            <div class="form-group">
                               <div class="form-line">
                                <select name="barang" id="cmb_barang" class="selectpicker form-control" data-live-search="true" required autofocus />
								<option value="">-- Pilih Asset  --</option>
								<?php
								
								$sql = $koneksi -> query("select * from barang_keluar order by kode_barang");
								while ($data=$sql->fetch_assoc()) {
									echo "<option value='$data[kode_barang].$data[nama_barang]'>$data[kode_barang] | $data[nama_barang]</option>";
								}
								?>
								
								</select>
                                     
									 
							</div>
                            </div>
							<div class="tampung2"></div>
							
                           
							
						
							
							
						
							
							<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
							
							</form>
							
							
							
							<?php
							
							if (isset($_POST['simpan'])) {
								$tanggal_keluar= $_POST['tanggal_keluar'];
								$tanggal_masuk= $_POST['tanggal_masuk'];
								
								$nama_supplier= $_POST['nama_supplier'];
								
								$barang= $_POST['barang'];
								$pecah_barang = explode(".", $barang);
								$kode_barang = $pecah_barang[0];
								$nama_barang = $pecah_barang[1];
								
								$sql = $koneksi->query("update tb_relasi1 set tanggal_keluar='$tanggal_keluar', tanggal_masuk='$tanggal_masuk', nama_supplier='$nama_supplier', nama_barang='$nama_barang', kode_barang='$kode_barang' where nama_supplier='$nama_supplier'"); 
								
								if ($sql) {
									?>
									
										<script type="text/javascript">
										alert("Data Berhasil Diubah");
										window.location.href="?page=supplier";
										</script>
										
										<?php
								}
							
								}
							
							
								
							?>
										
										
										
								
								
								
								
								
